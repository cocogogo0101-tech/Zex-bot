🚀 دليل البدء السريع

خطوات التشغيل السريعة

1️⃣ التحضير

# تثبيت المكتبات pip install -r requirements.txt # إنشاء ملف .env echo "DISCORD_TOKEN=your_token_here" > .env 

2️⃣ التشغيل

python main.py 

3️⃣ الإعداد الأولي

بعد تشغيل البوت وإضافته لسيرفرك، نفّذ هذه الأوامر:

أ) إعداد الترحيب

/setup welcome enabled:True channel:#الترحيب message:مرحباً {mention} في {server}! type:text 

ب) إعداد السجلات

/setup logs channel:#السجلات 

ج) إعداد دور الدعم (للتكتات)

/setup support role:@الدعم 

د) إعداد الحماية

/setup antispam enabled:True threshold:5 /setup antilink enabled:True 

هـ) تفعيل المستويات

/setup leveling enabled:True 

🎯 الاستخدام الأساسي

إدارة الأعضاء

# تحذير /warn @user سبب السبام أو: تحذير @user سبام # طرد /kick @user سبب المخالفة أو: اطرد @user مخالف # حظر /ban @user سبب الحظر أو: احظر @user مخالف # إسكات مؤقت /timeout @user 10m سبب أو: اسكت @user 10m سبب 

إدارة الرسائل

# مسح رسائل /purge 50 أو: امسح 50 

التكتات

# فتح تكت /ticket open سبب أو: تكت # إغلاق تكت /ticket close أو: اغلق # لوحة التكتات (في قناة) /ticket panel 

الردود التلقائية

# إضافة رد /autoresponse add trigger:السلام عليكم response:وعليكم السلام type:contains # عرض الردود /autoresponse list # حذف رد /autoresponse remove id:1 

🎨 أمثلة رسائل الترحيب

رسالة بسيطة

مرحباً {mention}! أهلاً بك في {server} 🎉 

رسالة متقدمة

👋 أهلاً {mention}! ━━━━━━━━━━━━━━━━ 🎉 مرحباً بك في **{server}** أنت العضو رقم **{membercount}** 📜 اقرأ القوانين في <#قناة_القوانين> 💬 تفاعل معنا في <#قناة_الدردشة> استمتع بوقتك! ✨ 

💡 نصائح سريعة

1. المتغيرات المتاحة

{mention} - منشن العضو

{user} - اسم العضو

{server} - اسم السيرفر

{membercount} - عدد الأعضاء

{channel} - اسم القناة

2. أنواع مطابقة الردود التلقائية

exact - مطابقة تامة

contains - يحتوي على

startswith - يبدأ بـ

endswith - ينتهي بـ

regex - تعبير نمطي (للمتقدمين)

3. صيغ الوقت

10s - 10 ثواني

5m - 5 دقائق

2h - ساعتين

1d - يوم واحد

🔧 الإعدادات الموصى بها

للسيرفرات الصغيرة (< 100 عضو)

/setup welcome enabled:True type:text /setup antispam enabled:True threshold:5 /setup leveling enabled:True 

للسيرفرات المتوسطة (100-1000 عضو)

/setup welcome enabled:True type:embed /setup goodbye enabled:True /setup antispam enabled:True threshold:5 /setup antilink enabled:True /setup leveling enabled:True /setup logs channel:#السجلات 

للسيرفرات الكبيرة (> 1000 عضو)

/setup welcome enabled:True type:embed /setup goodbye enabled:True /setup antispam enabled:True threshold:3 /setup antilink enabled:True /setup automod enabled:True /setup leveling enabled:True /setup logs channel:#السجلات /setup autorole role:@العضو 

📊 عرض الإحصائيات

# إحصائيات اليوم /stats # معلومات السيرفر /serverinfo # معلومات عضو /userinfo @user # لوحة الصدارة /leaderboard # رتبتك /rank 

❓ حل المشاكل الشائعة

المشكلة: البوت لا يرد على الأوامر

الحل:

تأكد من مزامنة الأوامر (تظهر في رسالة التشغيل)

تحقق من صلاحيات البوت

المشكلة: الترحيب لا يعمل

الحل:

تحقق من التفعيل: /config

تحقق من صلاحيات البوت في قناة الترحيب

تأكد من تحديد القناة الصحيحة

المشكلة: التكتات لا تُنشأ

الحل:

تحقق من صلاحيات البوت (إدارة القنوات)

تأكد من تحديد دور الدعم

🎮 أوامر سريعة للترفيه

/8ball سؤالك؟ /roll /coinflip /choose خيار1, خيار2, خيار3 /avatar @user 

📞 الدعم

إذا واجهت مشكلة:

راجع ملف README.md

تحقق من السجلات (logs) في الطرفية

تأكد من صلاحيات البوت

نصيحة: استخدم /config لعرض جميع إعداداتك الحالية في أي وقت!

