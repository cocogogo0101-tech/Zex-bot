🤖 بوت إدارة وترحيب متطور

بوت Discord احترافي مكتوب بـ Python باستخدام discord.py، مخصص للإدارة والترحيب مع ميزات ذكية ومتقدمة.

✨ الميزات

🎉 نظام الترحيب والوداع

رسائل ترحيب قابلة للتخصيص الكامل

دعم النصوص العادية و Embeds

متغيرات ديناميكية: {mention}, {user}, {server}, {membercount}

رسائل وداع عند المغادرة

دور تلقائي للأعضاء الجدد

🛡️ نظام الإدارة المتقدم

أوامر الإدارة: kick, ban, timeout, purge

نظام التحذيرات مع إجراءات تلقائية

التحقق من التسلسل الهرمي

سجل شامل لجميع الإجراءات

🤖 الردود التلقائية الذكية

إنشاء ردود تلقائية غير محدودة

أنواع مطابقة متعددة: (exact, contains, startswith, endswith, regex)

دعم المتغيرات في الردود

احتمالية الرد و cooldown

تحديد قنوات معينة للردود

قوالب جاهزة

🎫 نظام التكتات

فتح تكتات بأزرار تفاعلية

صلاحيات تلقائية للعضو ودور الدعم

إغلاق تلقائي مع حفظ المحادثة

لوحة إنشاء تكتات جاهزة

📊 نظام المستويات والخبرة

XP تلقائي عند إرسال الرسائل

لوحة صدارة

أوامر /rank و /leaderboard

رسائل الترقية التلقائية

🛡️ نظام الحماية

Anti-Spam: منع السبام التلقائي

Anti-Link: منع الروابط

Auto-Mod: كلمات محظورة قابلة للتخصيص

إجراءات تلقائية عند المخالفات

📝 نظام السجلات

تسجيل جميع الإجراءات

حذف/تعديل الرسائل

انضمام/مغادرة الأعضاء

kick/ban/timeout

إحصائيات يومية

⚙️ نظام الإعدادات

إعدادات ديناميكية بالكامل

لا حاجة لتعديل الكود

أوامر /setup شاملة

عرض الإعدادات بـ /config

📦 التثبيت

1. المتطلبات

Python 3.8+

pip

2. تثبيت المكتبات

pip install -r requirements.txt 

3. إعداد البوت

أنشئ ملف .env في المجلد الرئيسي

أضف التوكن:

DISCORD_TOKEN=your_token_here GUILD_ID=your_guild_id # اختياري 

4. تشغيل البوت

python main.py 

🎮 الأوامر

أوامر الإدارة

/kick @user [reason] - طرد عضو /ban @user [reason] - حظر عضو /timeout @user duration [reason] - إسكات مؤقت /warn @user reason - تحذير /warnings @user - عرض التحذيرات /clearwarnings @user - مسح التحذيرات /purge count - مسح رسائل 

أوامر الإعدادات

/setup welcome [enabled] [channel] [message] [type] /setup goodbye [enabled] [channel] [message] /setup logs channel /setup support role /setup autorole role /setup antispam [enabled] [threshold] /setup antilink [enabled] /setup leveling [enabled] /config - عرض الإعدادات 

أوامر الردود التلقائية

/autoresponse add trigger response [type] /autoresponse list /autoresponse remove id 

أوامر التكتات

/ticket open [reason] /ticket close /ticket panel - إنشاء لوحة تكتات 

أوامر عامة

/userinfo [@user] - معلومات عضو /serverinfo - معلومات السيرفر /rank [@user] - عرض المستوى /leaderboard - لوحة الصدارة /avatar [@user] - صورة البروفايل 

🎨 المتغيرات المتاحة

في رسائل الترحيب/الوداع والردود التلقائية:

{mention} - منشن العضو

{user} - اسم العضو

{server} - اسم السيرفر

{channel} - اسم القناة

{membercount} - عدد الأعضاء

🗂️ هيكل الملفات

├── main.py # الملف الرئيسي ├── database.py # قاعدة البيانات ├── config_manager.py # إدارة الإعدادات ├── helpers.py # دوال مساعدة ├── embeds.py # قوالب Embeds ├── permissions.py # نظام الصلاحيات │ ├── system_*.py # الأنظمة ├── event_*.py # الأحداث ├── cmd_*.py # الأوامر │ ├── .env # المتغيرات (لا يُرفع) ├── database.db # قاعدة البيانات (تُنشأ تلقائياً) ├── requirements.txt └── README.md 

🔧 التخصيص

إضافة رد تلقائي من الكود

await autoresponse_system.add_response( guild_id='123456789', trigger='مرحبا', response='أهلاً وسهلاً!', trigger_type='contains' ) 

تعديل إعدادات الترحيب

await config.setup_welcome( guild_id='123456789', enabled=True, channel_id='987654321', message='أهلاً {mention} في {server}!', type='text' ) 

📊 قاعدة البيانات

يستخدم البوت SQLite مع الجداول التالية:

settings - إعدادات السيرفرات

warnings - التحذيرات

tickets - التكتات

levels - المستويات

autoresponses - الردود التلقائية

blacklist_words - الكلمات المحظورة

logs - السجلات

notes - الملاحظات

lists - القوائم (blacklist/whitelist)

stats - الإحصائيات

reminders - التذكيرات

🤝 المساهمة

البوت مفتوح للتطوير! يمكنك:

إضافة ميزات جديدة

تحسين الكود

إصلاح الأخطاء

تحسين التوثيق

📝 الترخيص

هذا المشروع مجاني ومفتوح المصدر.

💡 ملاحظات

البوت مُحسّن للأداء العالي

يدعم سيرفر واحد أو متعدد

جميع الإعدادات قابلة للتخصيص

لا يحتاج تعديل كود للاستخدام

📞 الدعم

إذا واجهت أي مشكلة أو لديك اقتراح، لا تتردد في التواصل!

صُنع بـ ❤️ باستخدام discord.py

